import java.util.Random;

public class Main {
    public static void main(String[] args) {


    }
}