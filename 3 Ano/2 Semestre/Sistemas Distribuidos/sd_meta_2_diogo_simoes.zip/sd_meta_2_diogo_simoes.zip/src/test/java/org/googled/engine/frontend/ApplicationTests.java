package org.googled.engine.frontend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/**
 * Tests for the App class.
 */
@SpringBootTest
public class ApplicationTests {

	/**
	 * Constructs an instance of the AppTests class.
	 */
	public ApplicationTests() {
	}

	/**
	 * Tests that the context loads.
	 */
	@Test
	void contextLoads() {
	}

}
