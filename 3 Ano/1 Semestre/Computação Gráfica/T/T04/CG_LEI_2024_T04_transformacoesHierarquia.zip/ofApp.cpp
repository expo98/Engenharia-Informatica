#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	coutModelviewMatrix();


	A_w = gw() * 0.2;
	A_h = A_w;
	B_w = A_w * 0.5;
	B_h = 1.5 * A_h;
	C_w = B_w * 0.5;
	C_h = B_h;

	px = 0;
	py = 0;

	B_rot = 0;
	C_rot = 0;

	pos = ofVec3f(0., 0., 0.);
	speed = ofVec3f(0., 0., 0.);
	
}

//--------------------------------------------------------------
void ofApp::update(){
	//atualiza posicao do tiro
	pos += speed;
}

//--------------------------------------------------------------
void ofApp::draw(){

	glPushMatrix();//master push
	glTranslatef(gw() * 0.5, gh() * 0.5, 0.);
	glTranslatef(px, py, 0.);
	
	glColor3f(0, 1, 0);
	glPushMatrix();//A
	glScalef(A_w, A_h, 1.);
	rectFill_unit();
	glPopMatrix();

	glPushMatrix();//B
	glTranslatef(A_w * 0.5, 0, 0);
	glRotatef(B_rot, 0, 0, 1);

	glColor3f(1, 1, 0);
	glPushMatrix();//C
	glTranslatef(B_w * 0.5, -B_h * 0.5, 0.);
	glRotatef(C_rot, 0, 0, 1);
	glTranslatef(0, -C_h * 0.5, 0);
	
	glGetFloatv(GL_MODELVIEW_MATRIX, &C_center[0][0]);

	//top
	glPushMatrix();//push e pop sem desenho!
	glTranslatef(0, -C_h * 0.5, 0);
	glGetFloatv(GL_MODELVIEW_MATRIX, &C_top[0][0]);
	C_top_pos = getModelViewMatrixPos();
	glPopMatrix();

	//bottom
	glPushMatrix();//push e pop sem desenho!
	glTranslatef(0, C_h * 0.5, 0);
	glGetFloatv(GL_MODELVIEW_MATRIX, &C_bottom[0][0]);
	C_bottom_pos = getModelViewMatrixPos();
	glPopMatrix();


	glScalef(C_w, C_h, 1.);
	rectFill_unit();
	glPopMatrix();//C

	glColor3f(0, 0, 1);
	glScalef(B_w, B_h, 1.);
	rectFill_unit();

	//eixo de rotação do B
	glColor3f(1, 0, 1);
	glScalef(0.1, 0.1, 1.);
	rectFill_unit();
	glPopMatrix();//B


	glPopMatrix();//master


	//usa as coords obtidas da modelviewMatrix para desenhar o top/bottom/center do C
	//centro
	glColor3f(1, 0, 0);
	glPushMatrix();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glMultMatrixf(&C_center[0][0]);
	glScalef(C_w * 0.5, C_w * 0.5, 1.);
	rectFill_unit();
	glPopMatrix();

	//top
	glColor3f(1, 0, 0);
	glPushMatrix();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glMultMatrixf(&C_top[0][0]);
	glScalef(C_w * 0.5, C_w * 0.5, 1.);
	rectFill_unit();
	glPopMatrix();

	//bottom
	glColor3f(1, 0, 0);
	glPushMatrix();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glMultMatrixf(&C_bottom[0][0]);
	glScalef(C_w * 0.5, C_w * 0.5, 1.);
	rectFill_unit();
	glPopMatrix();


	//tiro
	glColor3f(0, 1, 1);
	glPushMatrix();
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glTranslatef(pos.x, pos.y, pos.z);
	glRotatef(B_rot + C_rot, 0, 0, 1);
	glScalef(C_w*0.9, C_h*0.2, 1.);
	rectFill_unit();
	glPopMatrix();

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	switch (key) {
		case OF_KEY_LEFT:
			px -= 10;
			break;
		case OF_KEY_RIGHT:
			px += 10;
			break;
		case OF_KEY_UP:
			py -= 10;
			break;
		case OF_KEY_DOWN:
			py += 10;
			break;
		case 'q':
			B_rot += 5;
			break;
		case 'a':
			B_rot -= 5;
			break;
		case 'w':
			C_rot += 5;
			break;
		case 's':
			C_rot -= 5;
			break;
		case ' '://tiro
			speed = (C_top_pos - C_bottom_pos);
			speed = 4.*speed.getNormalized();
			pos = (C_bottom_pos + C_top_pos)*0.5;
			break;

	}
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
