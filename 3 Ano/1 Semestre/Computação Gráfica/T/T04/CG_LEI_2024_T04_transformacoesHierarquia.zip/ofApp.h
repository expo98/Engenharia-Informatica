#pragma once

#include "ofMain.h"
#include "cg_extras.h"
#include "cg_drawing_extras.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();

		void keyPressed(int key);
		void keyReleased(int key);
		void mouseMoved(int x, int y );
		void mouseDragged(int x, int y, int button);
		void mousePressed(int x, int y, int button);
		void mouseReleased(int x, int y, int button);
		void mouseEntered(int x, int y);
		void mouseExited(int x, int y);
		void windowResized(int w, int h);
		void dragEvent(ofDragInfo dragInfo);
		void gotMessage(ofMessage msg);
		
		GLfloat A_w, A_h;
		GLfloat B_w, B_h;
		GLfloat C_w, C_h;

		GLfloat px, py;

		GLfloat B_rot;
		GLfloat C_rot;

		GLfloat C_center[4][4];
		GLfloat C_top[4][4];
		GLfloat C_bottom[4][4];

		ofVec3f C_top_pos;
		ofVec3f C_bottom_pos;
		
		//variaveis do tiro
		ofVec3f pos;
		ofVec3f speed;


};
