#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
    ofBackground(0, 0, 0);
    //glClearColor(0, 1, 0, 1);
    //glEnable(GL_DEPTH_TEST);
}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    perspective(60, 100, 1000);
    lookat(0, 0, gh()*0.5/tan(PI/6.), 0, 0, 0, 0, 1, 0);

    //com transparencia
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    wireframe();
    glColor4f(1, 1, 1, 1);
    glPushMatrix();
    glScalef(gw(), gh(), 1);
    malha_unit(20, 20);
    glPopMatrix();

    filled();
    glColor4f(1, 0, 0, 0.5);
    glPushMatrix();
    glTranslatef(-gw()*0.25, 0., 1.);
    glScalef(gw()*0.4, gh()*0.5, 1);
    rectFill_unit();
    glPopMatrix(); 

    glColor4f(0, 1, 0, 0.25);
    glPushMatrix();
    glTranslatef(-gw()*0.25, 0., 0.);
    glScalef(gw()*0.35, gh()*0.4, 1);
    rectFill_unit();
    glPopMatrix();

    glColor4f(0, 0, 1, 0.41);
    glPushMatrix();
    glTranslatef(-gw()*0.25, 0., 0.);
    glScalef(gw()*0.25, gh()*0.3, 1);
    rectFill_unit();
    glPopMatrix(); 


    //sem transparencia
    glEnable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    glColor4f(1, 0, 0, 0.5);
    glPushMatrix();
    glTranslatef(gw()*0.25, 0., 0.);
    glScalef(gw()*0.4, gh()*0.5, 1);
    rectFill_unit();
    glPopMatrix();

    glColor4f(0, 1, 0, 0.5);
    glPushMatrix();
    glTranslatef(gw()*0.25, 0., 0.01);
    glScalef(gw()*0.35, gh()*0.4, 1);
    rectFill_unit();
    glPopMatrix();

    glColor4f(0, 0, 1, 0.5);
    glPushMatrix();
    glTranslatef(gw()*0.25, 0., 0.2);
    glScalef(gw()*0.25, gh()*0.3, 1);
    rectFill_unit();
    glPopMatrix();
}

//--------------------------------------------------------------
void ofApp::exit(){

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseScrolled(int x, int y, float scrollX, float scrollY){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
