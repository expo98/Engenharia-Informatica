import java.util.EnumSet;
import java.util.Scanner;


public class Main {

    private static POOFs poofs = new POOFs();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("A inicializar o POO Financial Services...");
        // Carregar os dados caso existam (isso esta no proprio metodo)

        boolean ligado = true;

        while (ligado){

            mostrarMenu();
            System.out.print("Escolha uma opção: ");

            int opcao = scanner.nextInt();

            switch (opcao){
                case 1:
                    criarCliente();
                    break;
                case 2:
                    listarClientes();
                    break;
                case 3:
                    criarFatura();
                    break;
                case 4:
                    listarFaturas();
                    break;
                case 5:
                    visualizarFaturas();
                    break;
                case 6:

                    break;
                case 7:

                    break;
                case 8:
                    mostrarEstatisticas();
                    break;
                case 0:
                    System.out.println("Adeus!");
                    ligado = false;
                    break;
                default:
                    System.out.print("Opção inválida, tente novamente!\n Escolha uma opção: ");
            }
        }
    }

    private static void mostrarMenu(){
        System.out.println("1) Criar cliente");
        System.out.println("2) Listar clientes");
        System.out.println("3) Criar faturas");
        System.out.println("4) Listar faturas");
        System.out.println("5) Visualizar uma fatura");
        System.out.println("6) Importar faturas");
        System.out.println("7) Exportar faturas");
        System.out.println("8) Mostrar estatísticas");
        System.out.println("0) Sair");
    }
    public static void criarFatura(){
        poofs.criarFatura();
    }
    private static void mostrarEstatisticas(){
        poofs.mostrarEstatisticas();
    }

    private static void listarFaturas(){
        poofs.listarFaturas();
    }

    private static void visualizarFaturas(){

        System.out.print("Introduza o ID da fatura que deseja visualizar: ");
        int idFatura = scanner.nextInt();
        poofs.visualizarFaturaPorID(idFatura);
    }

    private static void criarCliente(){
        poofs.criarCliente();
    }

    private static void listarClientes(){
        poofs.listarCLientes();
    }

}