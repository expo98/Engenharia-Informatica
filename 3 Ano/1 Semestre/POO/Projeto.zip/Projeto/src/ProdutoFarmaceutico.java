public abstract class ProdutoFarmaceutico extends Produtos{


    //Cosntrutor
    public ProdutoFarmaceutico(int codigo, String nome, String descricao, int quantidade, double valorUnitario) {
        super(codigo, nome, descricao, quantidade, valorUnitario);
    }


}
