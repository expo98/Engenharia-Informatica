/*
import java.util.ArrayList;
import java.util.Random;

public class ArtQuestions extends AbstractQuestions {

    private ArrayList<String> questions = new ArrayList<String>();

    public ArtQuestions(int score, String question, ArrayList<String> questionOptions) {
        super(score, question, questionOptions);
        loadQuestions(questions);
    }

    @Override
    protected void loadQuestions(ArrayList<String> questions){
        this.questions=questions;
    }

}

 */