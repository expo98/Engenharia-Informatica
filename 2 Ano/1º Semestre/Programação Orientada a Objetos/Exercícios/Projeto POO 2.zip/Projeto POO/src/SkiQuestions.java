/*import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;
public class SkiQuestions extends AbstractQuestions {

    private ArrayList<String> questions = new ArrayList<String>();

    public SkiQuestions(int score, String question, ArrayList<String> questionOptions, int questionNumber,ArrayList<String> questions) {
        super(score, question, questionOptions, questionNumber);
    }

    @Override
    protected void loadQuestions(ArrayList<String> questions){
        Random random = new Random();
    }
}

 */