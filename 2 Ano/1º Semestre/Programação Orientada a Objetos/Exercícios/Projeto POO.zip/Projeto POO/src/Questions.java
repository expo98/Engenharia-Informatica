
abstract class Questions {
    abstract void QuestionFinally(int level);
}
