import java.io.*;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import java.util.Scanner;


public class ArtQuestions extends Questions {

    public ArrayList<String> EasyQuestions = new ArrayList<>();
    public ArrayList<String> MediumQuestions = new ArrayList<>();
    public ArrayList<String> HardQuestions = new ArrayList<>();
    public ArrayList<ArrayList<String>> EasyQuestionOptions = new ArrayList<>();
    public ArrayList<ArrayList<String>> MediumQuestionOptions = new ArrayList<>();
    public ArrayList<ArrayList<String>> HardQuestionOptions = new ArrayList<>();
    public ArrayList<String> EasyQuestionAnswers = new ArrayList<>();
    public ArrayList<String> MediumQuestionAnswers = new ArrayList<>();
    public ArrayList<String> HardQuestionAnswers = new ArrayList<>();

    public ArtQuestions() {
        // Initialize your ArrayLists here (populate them with data)
        initializeQuestions();
    }

    private void initializeQuestions() {
        try {
            File f = new File("Questions.txt");
            FileReader reader = new FileReader(f);
            BufferedReader br = new BufferedReader(reader);

            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\\|");

                String type = parts[0];

                if (Objects.equals(type, "Art")) {

                    ArrayList<String> Answers = new ArrayList<>();

                    String Difficulty = parts[1];
                    String Question = parts[2];
                    for (int i = 0; i < 4; i++) {
                        Answers.add(i, parts[3 + i]);
                    }

                    String CorrectAnswer = parts[parts.length - 1];

                    if (Objects.equals(Difficulty, "Easy")) {
                        EasyQuestions.add(Question);
                        for (int i = 0; i < 4; i++) {
                            EasyQuestionOptions.add(Answers);
                        }
                        EasyQuestionAnswers.add(CorrectAnswer);

                    } else if (Objects.equals(Difficulty, "Medium")) {
                        MediumQuestions.add(Question);
                        for (int i = 0; i < 4; i++) {
                            MediumQuestionOptions.add(Answers);
                        }
                        MediumQuestionAnswers.add(CorrectAnswer);

                    } else if (Objects.equals(Difficulty, "Hard")) {
                        HardQuestions.add(Question);
                        for (int i = 0; i < 4; i++) {
                            HardQuestionOptions.add(Answers);
                        }
                        HardQuestionAnswers.add(CorrectAnswer);
                    }

                }

            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }


    public ArrayList<String> GetQuestionsDifficulty(int difficulty){
        return switch (difficulty) {
            case 1 -> EasyQuestions;
            case 2 -> MediumQuestions;
            case 3 -> HardQuestions;
            default -> throw new IllegalStateException("Unexpected Value: " + difficulty);
        };
    }

    public int GetQuestionIndex(ArrayList<String> Questions){
        Random rand = new Random();
        return rand.nextInt(Questions.size());
    }

    public String GetQuestion(int difficulty,int questionIndex){
        return switch (difficulty) {
            case 1 -> EasyQuestions.get(questionIndex);
            case 2 -> MediumQuestions.get(questionIndex);
            case 3 -> HardQuestions.get(questionIndex);
            default -> throw new IllegalStateException("Unexpected Value: " + difficulty);
        };
    }

    public ArrayList<String> GetOptions(int difficulty, int questionIndex) {

        return switch (difficulty) {
            case 1 -> EasyQuestionOptions.get(questionIndex);
            case 2 -> MediumQuestionOptions.get(questionIndex);
            case 3 -> HardQuestionOptions.get(questionIndex);
            default -> throw new IllegalStateException("Unexpected Value: " + difficulty);
        };
    }

    public String GetAnswer(int difficulty, int questionIndex){
        return switch (difficulty) {
            case 1 -> EasyQuestionAnswers.get(questionIndex);
            case 2 -> MediumQuestionAnswers.get(questionIndex);
            case 3 -> HardQuestionAnswers.get(questionIndex);
            default -> throw new IllegalStateException("Unexpected Value: " + difficulty);
        };
    }



    @Override
    public void QuestionFinally(int level){
        int difficulty;
        int questionIndex;
        Scanner GuessScanner = new Scanner(System.in);

        ArrayList<String> Questions;
        String Question;
        ArrayList<String> Options;
        String Answer;
        String Guess;

        //Defines the difficulty of the question to be displayed
        //Based on the level that the player is at
        if( (1<=level) && (level <=5)){
            difficulty = switch (level) {
                case 1, 2 -> 1;
                case 3, 4 -> 2;
                case 5 -> 3;
                default -> throw new IllegalStateException("Value not expected: " + level);
            };
        }
        else throw new IllegalStateException("Unexpected Value: " + level);

        Questions = GetQuestionsDifficulty(difficulty);
        questionIndex = GetQuestionIndex(Questions);

        Question = GetQuestion(difficulty,questionIndex);
        Options = GetOptions(difficulty, questionIndex);
        Answer = GetAnswer(difficulty,questionIndex);

        System.out.printf("%s\n",Question);
        for (String option : Options) {
            System.out.printf("%s  ", option);
        }

        Guess = GuessScanner.nextLine();

        if (Objects.equals(Answer, Guess)) System.out.println("PARABÉNS!!!");
    }


}
