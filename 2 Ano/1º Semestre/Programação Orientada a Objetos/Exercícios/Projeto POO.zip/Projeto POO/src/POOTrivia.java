public class POOTrivia {
    public static void main(String[] args) {

        ArtQuestions ArtQuestion = new ArtQuestions();
        ArtQuestion.QuestionFinally(5);

        ScienceQuestions ScienceQuestion = new ScienceQuestions();
        ScienceQuestion.QuestionFinally(1);


        GUI gui = new GUI();
    }

}
