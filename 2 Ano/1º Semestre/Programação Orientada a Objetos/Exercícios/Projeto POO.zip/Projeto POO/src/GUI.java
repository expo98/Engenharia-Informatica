import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUI extends JFrame {

    private JFrame frame;
    private JPanel panel;

    public GUI(){
        frame = new JFrame();
        frame.setTitle("POOTrivia Game!");
        frame.setSize(1600, 1000);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel menuPanel = new JPanel(new BorderLayout());

        JLabel helloLabel = new JLabel("Who Wants To Be A POOlionaire?");
        helloLabel.setFont(new Font("Arial", Font.BOLD, 60));
        helloLabel.setHorizontalAlignment(SwingConstants.CENTER);
        menuPanel.add(helloLabel, BorderLayout.NORTH);

        JPanel rulesPanel = new JPanel(new FlowLayout()); // Painel para regras do jogo
        JLabel rulesLabel = new JLabel("<html>After the question is generated, choose the correct option!<br/>The questions can be either multiple choice or of the type true/false.<br/>If you choose the right option, your points tally will increase!<br/>Try to get the most points, and enjoy the quiz!</html>");
        rulesLabel.setFont(new Font("Comic Sans", Font.BOLD, 25));
        rulesPanel.add(rulesLabel);
        menuPanel.add(rulesPanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(); // Painel para botões
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
        JButton startButton = new JButton("Start game");
        JButton leaderboard = new JButton("Leaderboard");
        startButton.setPreferredSize(new Dimension(300,800));
        leaderboard.setPreferredSize(new Dimension(300,800));

        startButton.setFont(new Font("Comic Sans", Font.BOLD, 30));
        leaderboard.setFont(new Font("Comic Sans", Font.BOLD, 30));

        buttonPanel.add(Box.createHorizontalGlue()); // Adicionando espaço flexível à esquerda
        buttonPanel.add(startButton);
        buttonPanel.add(Box.createRigidArea(new Dimension(10, 0))); // Adicionando espaçamento fixo entre botões
        buttonPanel.add(leaderboard);
        buttonPanel.add(Box.createHorizontalGlue()); // Adicionando espaço flexível à direita
        menuPanel.add(buttonPanel, BorderLayout.SOUTH);



        frame.setContentPane(menuPanel);
        frame.setVisible(true);

    }

}

