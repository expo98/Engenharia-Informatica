public class SportsQuestions extends Questions {
    String[] Questions;
    String[] QuestionOptions ={
            "Verdadeiro",
            "Falso"
    };
    char[] QuestionAnswers;
    char QuestionGuess;

    void QuestionFinally(int level){
        System.out.println("ScienceQuestions");
    }

}
