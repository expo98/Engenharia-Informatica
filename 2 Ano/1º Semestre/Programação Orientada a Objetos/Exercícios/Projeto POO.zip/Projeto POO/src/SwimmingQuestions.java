public class SwimmingQuestions extends SportsQuestions {
    public String[] EasyQuestions = {
            "Q1",
            "Q2",
            "Q3",
            "Q4"
    };

    public String[] MediumQuestions = {
            "Q1",
            "Q2",
            "Q3",
            "Q4"
    };

    public String[] HardQuestions = {
            "Q1",
            "Q2",
            "Q3",
            "Q4"
    };

    public char[] EasyQuestionsAnswers = {
            'V',
            'V',
            'F',
            'F'

    };

    public char[] MediumQuestionsAnswers = {
            'V',
            'V',
            'F',
            'F'

    };

    public char[] HardQuestionsAnswers = {
            'V',
            'V',
            'F',
            'F'

    };

}
