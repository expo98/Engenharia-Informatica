# Simulador de Sistema de Autorização de Serviços Móveis 5G
Projeto para a cadeira de Sistemas Operativos - 2023/2024

Autores: Miguel Pereira e Carlos Pereira

