public class CharacterInheritance {

}
