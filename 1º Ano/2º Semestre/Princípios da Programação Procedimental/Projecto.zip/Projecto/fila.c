#include <stdio.h>
#include <stdlib.h>
#include "fila.h"

void criarFila (tipoFila *fila){
    fila->inicio = NULL;
    fila->fim = NULL;
}

int vaziaFila(tipoFila *fila){
    if(fila->inicio == NULL)
        return 1;
    else
        return 0;
}

void destruirFila(tipoFila *fila){
    noCliente *temp_ptr;
    while(!emptyQueue(fila)){
        temp_ptr = fila->inicio;
        fila->inicio = fila->inicio->prox;
        free(temp_ptr);
    }
    fila->fim = NULL;
}

void adicionarCliente(tipoFila *fila, clientInfo cliente)
{
    noCliente *temp_ptr;
    temp_ptr = (noCliente *) malloc(sizeof (noCliente));

    char nome[50];
    int ano,mes,dia;
    int horas,minutos,bloco;
    int servico; // duracao

    printf("Nome do Cliente? ");
    fgets(nome,50,stdin);

    while (servico != 1 || servico != 2)
    {            
    printf("Tipo de serviços \n 1) Lavagem \n 2) Manutenção\n");
    scanf("%d",&servico);
    }
    printf("Para que horas o serviço?\n ");

    while (horas<8 && horas>17)
    {        
    printf("Introduza a hora (sem os minutos)\n");
    scanf("%d",&horas);
    }
    while (minutos != 00 || minutos != 30)
    {
        printf("Introduza os minutos\n");
        scanf("%d", &minutos);
    }
}
/*
struct myItem removerCliente(tipoFila *fila){
    noCliente *temp_ptr;
    struct myItem item = {1,0};
    temp_ptr = fila->inicio;
    item = temp_ptr->myItemQueue;
    fila->inicio = fila->inicio->prox;
    if(emptyQueue(fila))
        fila->fim = NULL;
    free(temp_ptr);
    return (item);
}
*/