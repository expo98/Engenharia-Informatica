#ifndef FICHA1111_MYQUEUE_H
#define FICHA1111_MYQUEUE_H

typedef struct clientInfo
{
    char nome[50];
    int ano,mes,dia;
    int horas,minutos;
    int servico;
}clientInfo;

typedef struct noCliente{
    clientInfo myItemQueue;
    int prioridade;
    struct noCliente *prox;
} noCliente;

typedef struct tipoFila{
    noCliente *inicio;
    noCliente *fim;
} tipoFila;

void criarFila (tipoFila *fila);
int vaziaFila(tipoFila *fila);
void destruirFila(tipoFila *fila);
void adicionarCliente(tipoFila *fila, clientInfo cliente);
clientInfo removerCliente(tipoFila *fila);

#endif //FICHA1111_MYQUEUE_H