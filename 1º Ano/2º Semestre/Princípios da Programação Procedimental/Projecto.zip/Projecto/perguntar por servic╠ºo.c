#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct clientInfo
{
    char nome[50];
    int ano,mes,dia;
    int horas,minutos;
    int servico;
}clientInfo;

typedef struct no
{
    clientInfo cliente;
    int prioridade; // 1- reserva 2- pré-reserva
    struct no *next;
}no_reserva;

typedef struct 
{
    no_reserva *head;
    no_reserva *tail;
} tipoFila;

void cria(tipoFila *fila);  

int main()
{
    char nome[50];
    int ano,mes,dia;
    int horas,minutos,bloco;
    int servico; // duracao

    printf("Nome do Cliente? ");
    fgets(nome,50,stdin);

    while (servico != 1 || servico != 2)
    {            
    printf("Tipo de serviços \n 1) Lavagem \n 2) Manutenção\n");
    scanf("%d",&servico);
    }
    printf("Para que horas o serviço?\n ");

    while (horas<8 && horas>17)
    {        
    printf("Introduza a hora (sem os minutos)\n");
    scanf("%d",&horas);
    }
    while (minutos != 00 || minutos != 30)
    {
        printf("Introduza os minutos\n");
        scanf("%d", &minutos);
    }
    
// VERIFICAR SE EXISTE ALGUM NÓ COM PRIORIDADE 1 QUE ESTEJA NO HORARIO DO SERVICO
// SE NÃO, METER NA LISTA DE RESERVAS (PRIORIDADE 1)
// SE SIM, PERGUNTAR SE QUER METER NA LISTA DE PRÉ-RESERVAS (PRIORIDADE 2)
    
    no_reserva * temp_ptr;
    temp_ptr = (no_reserva *) malloc(sizeof (no_reserva));

    clientInfo cliente;
    strcpy(cliente.nome, nome);
    cliente.horas=horas;
    cliente.minutos=minutos;
    cliente.servico=servico;
    
    


    
    return 0;
}